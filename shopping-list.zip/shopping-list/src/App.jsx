function App() {
  return (
    <h1>Shoppping List</h1>
  );
}

export default App
